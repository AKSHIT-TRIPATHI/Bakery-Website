<footer class="footer">

   <section class="grid">

      <div class="box">
         <img src="images/email-icon.png" alt="">
         <h3>our email</h3>
         <a href="mailto:shaikhanas@gmail.com">sharmaakshit820@gmail.com</a>
         <a href="mailto:anasbhai@gmail.com">akshit.tripathi@lpu.in</a>
      </div>

      <div class="box">
         <img src="images/clock-icon.png" alt="">
         <h3>Opening hours</h3>
         <p>7:00am to 10:30pm</p>
      </div>

      <div class="box">
         <img src="images/map-icon.png" alt="">
         <h3>Our address</h3>
         <a href="#">Ajmer, india - 305007</a>
      </div>

      <div class="box">
         <img src="images/phone-icon.png" alt="">
         <h3>Our number</h3>
         <a href="tel:1234567890">861-956-9762</a>
         <a href="tel:1112223333">861-956-9242</a>
      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>Akshit tripathi.</span> | all rights reserved!</div>

</footer>

<div class="loader">
   <img src="images/loader.gif" alt="">
</div>